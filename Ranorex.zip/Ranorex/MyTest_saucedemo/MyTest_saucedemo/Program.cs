﻿using System;
using Ranorex;
using Ranorex.Core.Testing;

namespace MyTest_saucedemo
{
    class Program
    {
        [STAThread]
        public static int Main(string[] args)
        {
            // Налаштування клавіші для зупинки тесту
            Keyboard.AbortKey = System.Windows.Forms.Keys.Pause;

            int error = 0;

            try
            {
                // Логування початку виконання тестів
                Report.Log(ReportLevel.Info, "Test Execution", "Starting test execution...");

                // Запуск тестового набору
                error = TestSuiteRunner.Run(typeof(Program), Environment.CommandLine);

                // Логування успішного завершення
                if (error == 0)
                {
                    Report.Log(ReportLevel.Success, "Test Execution", "All tests passed successfully.");
                }
                else
                {
                    Report.Log(ReportLevel.Failure, "Test Execution", $"Some tests failed. Error code: {error}");
                }
            }
            catch (Exception e)
            {
                // Логування помилок
                Report.Error("Unexpected exception occurred: " + e.ToString());
                error = -1;
            }

            // Логування завершення тестів
            Report.Log(ReportLevel.Info, "Test Execution", "Test execution completed.");
            return error;
        }
    }
}
